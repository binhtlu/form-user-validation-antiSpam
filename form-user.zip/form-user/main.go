package main

import (
	"controllers/handle"
)

func main() {
	//remoteAddr := ctx.Request.RemoteAddr
	handle.HandlerRequest()
}
